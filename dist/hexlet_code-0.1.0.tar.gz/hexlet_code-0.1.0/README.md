### Hexlet tests and linter status:
[![Actions Status](https://github.com/SnawBilly/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/SnawBilly/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/8e382d7c95fc535d26a3/maintainability)](https://codeclimate.com/github/SnawBilly/python-project-49/maintainability)
